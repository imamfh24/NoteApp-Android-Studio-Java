<?php
$conn = mysqli_connect("Host DB", "User DB", "your password db" , "Nama DB");
